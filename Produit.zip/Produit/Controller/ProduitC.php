<?php
	include_once '../../config.php';
	include_once '../../Model/Produit.php';
	class produitC 
{

	function ajouterproduit($produit)
	{
	$sql="INSERT INTO produit (matricule,marque,modele,prix_pr,categorie) 
	VALUES (:matricule, :marque, :modele, :prix_pr, :categorie)";
	$db = config::getConnexion();
	try{
		$query = $db->prepare($sql);
		$query->execute([
			'matricule' => $produit->getmatricule(),
			'marque' => $produit->getmarque(),
			'modele' => $produit->getmodele(),
			'prix_pr' => $produit->getprix_pr(),
			'categorie' => $produit->getcategorie()
		]);			
	}
	catch (Exception $e){
		echo 'Erreur: '.$e->getMessage();
	}			
	}
	
    function afficherproduit()
    {
		$sql="SELECT * FROM produit";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
    }

    function modifierproduit($produit, $matricule)
	{
        try {
            $db = config::getConnexion();
            $query = $db->prepare(
                'UPDATE produit SET 
                    marque= :marque, 
                    modele= :modele, 
                    prix_pr= :prix_pr, 
                    categorie= :categorie, 
                WHERE matricule= :matricule'
            );
            $query->execute([
                'marque' => $produit->getmarque(),
                'modele' => $produit->getmodele(),
                'prix_pr' => $produit->getprix_pr(),
                'categorie' => $produit->getcategorie(),
                'matricule' => $matricule
            ]);
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }

    function supprimerproduit($matricule)
	{
        $sql="DELETE FROM produit WHERE matricule=:matricule";
        $db = config::getConnexion();
        $req=$db->prepare($sql);
        $req->bindValue(':matricule', $matricule);
        try{
            $req->execute();
        }
        catch(Exception $e){
            die('Erreur:'. $e->getMeesage());
        }
    }
    



    function recupererproduit($matricule){
        $sql="SELECT * from produit WHERE matricule= '$matricule'";
		$db = config::getConnexion();
		try{
            $query=$db->prepare($sql);
            $query->execute();

            $produit=$query->fetch();
            return $produit;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }


}


    

?>