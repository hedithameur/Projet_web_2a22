<?php
	include '../../Controller/ProduitC.php';
	$produitC=new produitC();
	$produitC->supprimerproduit($_GET["matricule"]);
	header('Location:afficherListeProduits.php');
?>