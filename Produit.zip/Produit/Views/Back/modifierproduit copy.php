<?php
    include_once '../../Model/Produit.php';
    include_once '../../Controller/ProduitC.php';

    $error = "";

    // create produit
    $produit = null;

    // create an instance of the controller
    $produitC = new produitC();
    if (
        isset($_POST["matricule"]) &&
		isset($_POST["marque"]) &&		
        isset($_POST["modele"]) &&
		isset($_POST["prix_pr"]) 
    ) {
        if (
            !empty($_POST["matricule"]) && 
			!empty($_POST["marque"]) &&
            !empty($_POST["modele"]) && 
			!empty($_POST["prix_pr"])
        ) {
            $produit = new produit(
                $_POST['matricule'],
				$_POST['marque'],
                $_POST['modele'], 
				$_POST['prix_pr']
            );
            $produitC->modifierproduit($produit, $_POST['matricule']);
            header('Location:afficherListeProduits.php');
        }
        else
            $error = "Missing information";
    }    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit product</title>
</head>
    <body>
        <button><a href="afficherListeProduits.php">Retour à la liste des produits</a></button>
        <hr>
        
        <div id="error">
            <?php echo $error; ?>
        </div>
			
		<?php
			if (isset($_POST['matricule'])){
			$produit = $produitC->recupererproduit($_POST['matricule']);
				
		?>
        
        <form action="" method="POST">
            <table border="1" align="center">
                <tr>
                    <td>
                        <label for="matricule">Matricule:
                        </label>
                    </td>
                    <td><input type="text" name="matricule" id="matricule" value="<?php echo $produit['matricule']; ?>" maxlength="20"></td>
                </tr>
				<tr>
                    <td>
                        <label for="marque">Marque:
                        </label>
                    </td>
                    <td><input type="text" name="marque" id="marque" value="<?php echo $produit['marque']; ?>" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="modele">Modele:
                        </label>
                    </td>
                    <td><input type="text" name="modele" id="modele" value="<?php echo $produit['modele']; ?>" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="prix_pr">prix:
                        </label>
                    </td>
                    <td>
                        <input type="float" name="prix_pr" id="prix_pr" value="<?php echo $produit['prix_pr']; ?>" maxlength="20">
                    </td>
                </tr>
                         
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Modifier" onclick="ajout(event)"  class="btn btn-warning waves-effect waves-light"> 
                    </td> 
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
		<?php
		}
		?>

<script>
function ajout(event) {
    if ( matricule() == 0 || marque() == 0 ||modele() == 0  || prix_pr()==0 )
    
        produit.preventDefault();
    }

</script>

    </body>
</html>