<?php
    include_once '../../Model/Categorie.php';
    include_once '../../Controller/CategorieC.php';

    $error = "";

    // create Categorie
    $categorie = null;

    // create an instance of the controller
    $categorieC = new CategorieC();
    if (
        isset($_POST["idC"]) &&
		isset($_POST["nomC"])  
    ) {
        if (
            !empty($_POST["idC"]) && 
			!empty($_POST["nomC"])
        ) {
            $categorie = new categorie(
                $_POST['idC'],
				$_POST['nomC']
            );
            $categorieC->modifiercategorie($categorie, $_POST["idC"]);
            header('Location:afficherListeProduits.php');
        }
        else
            $error = "Missing information";
    }    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit category</title>
</head>
    <body>
        <button><a href="afficherListeProduits.php">Retour à la liste des categories</a></button>
        <hr>
        
        <div id="error">
            <?php echo $error; ?>
        </div>
			
		<?php
			if (isset($_POST['idC'])){
			$categorie = $categorieC->recuperercategorie($_POST['idC']);
				
		?>
        
        <form action="" method="POST">
            <table border="1" align="center">
                <tr>
                    <td>
                        <label for="idC">ID Categorie:
                        </label>
                    </td>
                    <td><input 
                    type="number" 
                    name="idC" 
                    id="idC" 
                    value="<?php echo $categorie['idC']; ?>" 
                    maxlength="20"></td>
                </tr>
				<tr>
                    <td>
                        <label for="nomC">Nom Categorie:
                        </label>
                    </td>
                    <td><input type="text" name="nomC" id="nomC" value="<?php echo $categorie['nomC']; ?>" maxlength="20"></td>
                </tr>

                         
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Modifier"> 
                    </td>
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
		<?php
		}
		?>
    </body>
</html>