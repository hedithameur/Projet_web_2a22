<?php
	include_once '../../Controller/ProduitC.php';
  include_once '../../Controller/CategorieC.php';
	$produitC=new produitC();
	$listeProduits=$produitC->afficherproduit(); 
  $categorieC=new categorieC();
	$listeCategories=$categorieC->affichercategorie(); 



?>
<html lang="en">
	<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
	<title>product</title>
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Roboto:400,700"
    />
    <!-- https://fonts.google.com/specimen/Roboto -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css" />
    <!-- https://fontawesome.com/ -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <!-- https://getbootstrap.com/ -->
    <link rel="stylesheet" href="assets/css/templatemo-style.css">
    <!--
	Product Admin CSS Template
	https://templatemo.com/tm-524-product-admin
	-->   
	</head>
	<body id="reportsPage">
    <nav class="navbar navbar-expand-xl">
      <div class="container h-100">
        <a class="navbar-brand" href="index.html">
          <h1 class="tm-site-title mb-0">Product Admin</h1>
        </a>
        <button
          class="navbar-toggler ml-auto mr-0"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <i class="fas fa-bars tm-nav-icon"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mx-auto h-100">
            <li class="nav-item">
              <a class="nav-link" href="index.html">
                <i class="fas fa-tachometer-alt"></i> Dashboard
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a
                class="nav-link dropdown-toggle"
                href="#"
                id="navbarDropdown"
                role="button"
                data-toggle="dropdown"
                aria-haspopup="true"
                aria-expanded="false">
                <i class="far fa-file-alt"></i>
                <span> Reports <i class="fas fa-angle-down"></i> </span>
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Daily Report</a>
                <a class="dropdown-item" href="#">Weekly Report</a>
                <a class="dropdown-item" href="#">Yearly Report</a>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="products.html">
                <i class="fas fa-shopping-cart"></i> Products
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="accounts.html">
                <i class="far fa-user"></i> Accounts
              </a>
            </li>
            <li class="nav-item dropdown">
              <a
                class="nav-link dropdown-toggle"
                href="#"
                id="navbarDropdown"
                role="button"
                data-toggle="dropdown"
                aria-haspopup="true"
                aria-expanded="false">
                <i class="fas fa-cog"></i>
                <span> Settings <i class="fas fa-angle-down"></i> </span>
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Profile</a>
                <a class="dropdown-item" href="#">Billing</a>
                <a class="dropdown-item" href="#">Customize</a>
              </div>
            </li>
          </ul>
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link d-block" href="login.html">
                Admin, <b>Logout</b>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

	<div class="container mt-5">
      <div class="row tm-content-row">
        <div class="col-sm-12 col-md-12 col-lg-8 col-xl-8 tm-block-col">
          <div class="tm-bg-primary-dark tm-block tm-block-products">
            <div class="tm-product-table-container">



			<h2 class="tm-block-title">Liste des produits</h2>



      


		<table class="table table-hover tm-table-small tm-product-table" border="1" align="center">

		<thead>
			<tr>
			<!--	<th scope="col">&nbsp;</th>  -->
				<th scope="col">Matricule</th>
				<th scope="col">Marque</th>
				<th scope="col">Modele</th>
				<th scope="col">Prix</th>
				<th scope="col">Num Categorie</th>
				<th scope="col">&nbsp;</th>
				<th scope="col">&nbsp;</th>

			</tr>
		</thead>
    <tbody>
		
			<?php
				foreach($listeProduits as $produit){
			?>
			<tr>
<!--			<th scope="row"><input type="checkbox" /></th>  -->
                    <td class="tm-product-name"><?php echo $produit['matricule']; ?></td>
                    <td><?php echo $produit['marque']; ?></td>
                    <td><?php echo $produit['modele']; ?></td>
                    <td><?php echo $produit['prix_pr'];?></td>
                    <td><?php echo $produit['categorie'];?></td>
					<td>
					<form method="POST" action="modifierproduit.php">
						<input type="submit" name="Modifier" value="Modifier">
						<input type="hidden" value=<?PHP echo $produit['matricule']; ?> name="matricule">
					</form>
				</td>
                    <td>
					<a href="supprimerproduit.php?matricule=<?php echo $produit['matricule']; ?>" 
           href="#" class="tm-product-delete-link">
                        <i class="far fa-trash-alt tm-product-delete-icon"></i>
                      </a>
                    </td>
			</tr>
        </tbody>
			<?php
				}
			?>
		</table>

    
    
  </div>










  <a
              href="ajouterproduit.php"
              class="btn btn-primary btn-block text-uppercase mb-3">Ajouter Produit</a>
<!--            <button class="btn btn-primary btn-block text-uppercase">
              Delete selected products
            </button>  -->

          </div>
        </div>



  <div class="col-sm-12 col-md-12 col-lg-4 col-xl-4 tm-block-col">
          <div class="tm-bg-primary-dark tm-block tm-block-product-categories">
            <h2 class="tm-block-title">Product Categories</h2>
            <div class="tm-product-table-container">
              <table class="table tm-table-small tm-product-table">

              <thead>
			<tr>
			<!--	<th scope="col">&nbsp;</th>  -->
				<th scope="col">ID</th>
				<th scope="col">Nom categorie</th>
				<th scope="col">&nbsp;</th>
				<th scope="col">&nbsp;</th>

        

			</tr>
		</thead>

    <tbody>
    <?php
				foreach($listeCategories as $categorie){
			?>

  <tr>
          <td class="tm-product-name"><?php echo $categorie['idC']; ?></td>
          <td ><?php echo $categorie['nomC']; ?></td>         
          <td class="text-center">

          
          <a href="supprimercategorie.php?idC=<?php echo $categorie['idC']; ?>" 
          href="#" class="tm-product-delete-link">
          <i class="far fa-trash-alt tm-product-delete-icon"></i>
          </a>
                    </td>

                    <td>
					<form method="POST" action="modifiercategorie.php">
						<input type="submit" name="Modifier" value="Modifier">
						<input type="hidden" value=<?PHP echo $categorie['idC']; ?> name="idC">
					</form>
				</td>
                  </tr>
                </tbody>
                <?php
				}
			?>
                
              </table>
            </div>
            <a
              href="ajoutercategorie.php"
              class="btn btn-primary btn-block text-uppercase mb-3">
              Ajouter categorie</a>

          </div>
        </div>
      </div>
    </div>



		<footer class="tm-footer row tm-mt-small">
      <div class="col-12 font-weight-light">
        <p class="text-center text-white mb-0 px-4 small">
          Copyright &copy; <b>2022</b> All rights reserved. 
          
          Design: <a rel="nofollow noopener" href="https://templatemo.com" class="tm-footer-link">Template Mo</a>
        </p>
      </div>
    </footer>
		<script src="assets/js/jquery-3.3.1.min.js"></script>
    <!-- https://jquery.com/download/ -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- https://getbootstrap.com/ -->
    <script>
      $(function() {
        $(".tm-product-name").on("click", function() {
          window.location.href = "modifierproduit.php";
        });
      });
    </script>

	</body>
</html>
