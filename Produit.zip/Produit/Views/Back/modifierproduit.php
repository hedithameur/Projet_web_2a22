<?php
    include_once '../../Model/Produit.php';
    include_once '../../Controller/ProduitC.php';

    $error = "";

    // create produit
    $produit = null;

    // create an instance of the controller
    $produitC = new produitc();
    if (
        isset($_POST["matricule"]) &&
		isset($_POST["marque"]) &&		
        isset($_POST["modele"]) &&
		isset($_POST["prix_pr"])
    ) {
        if (
            !empty($_POST["matricule"]) && 
			!empty($_POST['marque']) &&
            !empty($_POST["modele"]) && 
			!empty($_POST["prix_pr"])
        ) {
            $produit = new produit(
                $_POST['matricule'],
				$_POST['marque'],
                $_POST['modele'], 
				$_POST['prix_pr']
            );
            $produitC->modifierproduit($produit, $_POST["matricule"]);
            header('Location:afficherListeProduits.php');
        }
        else
            $error = "Missing information";
    }    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Display</title>
</head>
    <body>
        <button><a href="afficherListeProduits.php">Retour à la liste des produit</a></button>
        <hr>
        
        <div id="error">
            <?php echo $error; ?>
        </div>
			
		<?php
			if (isset($_POST['matricule'])){
				$produit = $produitC->recupererproduit($_POST['matricule']);
				
		?>
        
        <form action="" method="POST">
            <table border="1" align="center">
                <tr>
                    <td>
                        <label for="matricule">Numéro produit:
                        </label>
                    </td>
                    <td><input type="text" name="matricule" id="matricule" value="<?php echo $produit['matricule']; ?>" maxlength="20"></td>
                </tr>
				<tr>
                    <td>
                        <label for="marque">marque:
                        </label>
                    </td>
                    <td><input type="text" name="marque" id="marque" value="<?php echo $produit['marque']; ?>" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="modele">modele:
                        </label>
                    </td>
                    <td><input type="text" name="modele" id="modele" value="<?php echo $produit['modele']; ?>" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="prix_pr">prix_pr:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="prix_pr" value="<?php echo $produit['prix_pr']; ?>" id="prix_pr">
                    </td>
                </tr>
                           
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Modifier"> 
                    </td>
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
		<?php
		}
		?>
    </body>
</html>